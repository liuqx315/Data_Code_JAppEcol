rm(list = ls())
library("ggplot2")
library("dplyr")
library("RColorBrewer")
library("ggsci")
library("scales")
stderr <- function(x) sqrt(var(x,na.rm=T)/length(which(!is.na(x))))
OpenWindow = function (WinWidth,WinHeight) {
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz(width=WinWidth, height=WinHeight, 
           title=" ")
  } else
    windows(width = WinWidth, height = WinHeight,
            title=" ")
}
SaveFigure=function(FileName){
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz.save(paste(FileName,'.pdf',sep=''),type = c("pdf"),device = dev.cur())
  } else
    savePlot(filename = FileName,type = c("pdf"),device = dev.cur(),restoreConsole = TRUE) 
}

dat = read.csv("Pattern_Connectance2019.csv")
dat = dat[dat$Week <= 11,]
site = c(paste0(dat$Transect,seq="-",dat$Replicate,seq="-",dat$Plot))
dat = cbind(site,dat)
dat = dat[-which(is.na(dat$Plant_Density)),]
dat$Connectivity = as.character(dat$Connectivity)
dat$Pattern = as.character(dat$Pattern)
dat_High = dat[dat$Elevation == "High elevation",]
dat_Low = dat[dat$Elevation == "Low elevation",]
dat$Connectivity = factor(dat$Connectivity)
dat$Pattern = factor(dat$Pattern)
dat_High$site = factor(dat_High$site)
####calculate increase rate#########
rate <- function(x){
  diff(x)/x[-length(x)]
}
#####High elevation######
dat_HR = tapply(dat_High$Plant_Density,dat_High$site,rate)
Rate = c()
for (i in c(1:length(dat_HR))){
  # print(i)
  Rate = c(Rate,dat_HR[[i]])
}

dat_High = dat_High[-which(dat_High$Week == 0),]
dat_High = dat_High[order(dat_High$site),]
dat_High = cbind(dat_High,Rate)
dat_High$Rate[dat_High$Week == 11] = dat_High$Rate[dat_High$Week == 11]/2
#####Low elevation######
dat_Low$site = factor(dat_Low$site)
dat_LR = tapply(dat_Low$Plant_Density,dat_Low$site, rate)
Rate = c()
for (i in c(1:length(dat_LR))){
  print(i)
  Rate = c(Rate,dat_LR[[i]])
}
dat_Low = dat_Low[order(dat_Low$site),]
dat_Low = dat_Low[-which(dat_Low$Week == 0),]
dat_Low = cbind(dat_Low,Rate)
####rbind both elevation and correct data####
dat_Rate = rbind(dat_High,dat_Low)
adjust_site_high= c()
j = 1
dat_High = dat_High[-which(dat_High$site == "1-3-3"),]
dat_High$site = factor(dat_High$site)
for(i in levels(dat_High$site)){
  if(isTRUE(length(dat_High$Week[dat_High$site == i]) < 10)){
    print(i)
    print(length(dat_High$Week[dat_High$site == i]))
    adjust_site_high[j] = c(i) 
    j = j+1
  }
}
adjust_site_low = c()
m = 1
dat_Low$site = factor(dat_Low$site)
for(n in levels(dat_Low$site)){
  if(isTRUE(length(dat_Low$Week[dat_Low$site == n]) < 11)){
    print(n)
    print(length(dat_Low$Week[dat_Low$site == n]))
    adjust_site_low[m] = c(n) 
    m = m+1
  }
}
adjust_site = c(adjust_site_high,adjust_site_low)
dat_Rate = rbind(dat_High,dat_Low)
for(adjust in adjust_site){
  nweek= which(diff(dat_Rate$Week[dat_Rate$site == adjust]) != 1)+1
  dat_Rate$Rate[dat_Rate$site == adjust][nweek] = dat_Rate$Rate[dat_Rate$site == adjust][nweek]/2
}
colnames(dat_Rate)[which(colnames(dat_Rate) == "Connectivity")]<-"Connectance"
dat_Rate$Connectance[dat_Rate$Connectance == "High connectivity"]<-"High connectance"
dat_Rate$Connectance[dat_Rate$Connectance == "Low connectivity"]<-"Low connectance"
dat_Rate$Connectance[dat_Rate$Connectance == "No connectivity"]<-"No connectance"
Colors = pal_jco("default",alpha = 0.75)(10)
Colors = Colors[c(1,2,8)]

# dat_Rate_mean = dat_Rate %>% group_by(Elevation,Pattern,Connectance,Week)%>%
#   summarise(rate.se = stderr(Rate),rate.mean = mean(Rate))
####figure#####################
OpenWindow(12,7.5)
pp<- ggplot(dat_Rate,aes(x=Week,y=Rate,group=Connectance,color=Connectance,shape=Connectance ))+
  facet_grid(Elevation~Pattern,space='fixed')+
  # plot lines
  geom_point(size=3)+
  # geom_errorbar(aes(ymin=rate.mean-rate.se, ymax=rate.mean+rate.se),width = 0.3,size = 1.2)+
  # geom_line(size = 1.5)+
  geom_smooth(method = "loess",size = 1.5)+ ##estimate trend of each treatment#####
theme(panel.background = element_rect(fill = "transparent",colour = "black"),
      panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
  labs(x="Time (week)",y=c("Reproduction rate "))+
  ggtitle("")+
  scale_color_manual(values=Colors)+
  ylim(-0.75,1.70)+
  guides(fill=guide_legend("title"))+
  theme_bw()+
  theme(plot.title = element_text(size=18,hjust=0.5),
        # text = element_text(family="Times New Roman",color = "black"),
        legend.text = element_text(size=18,hjust=0.5),
        legend.title = element_text(size=18,face = 'bold'),
        legend.key=element_rect(fill='NA'),
        axis.title.x = element_text(size = 18,vjust = 0.5),
        axis.title.y = element_text(size = 18,vjust = 0.5),
        strip.text.x = element_text(size=18,face="bold"),
        strip.text.y = element_text(size=18,face="bold"),
        axis.text.x = element_text(size=14,color='black'),
        axis.text.y = element_text(size=14,color='black'),
        plot.margin = margin(t=0.0, r=0.1, b=0.12, l=0.1, "cm")
  )+scale_x_continuous(breaks=seq(0,12,2))+
  geom_hline(yintercept = 0,linetype=2,lwd=1)+
  geom_vline(xintercept = 4,linetype=2,lwd=0.6)+
  # annotate("text",x=1.5,y=275,label="n=6",size = 6)+
  theme(legend.position="top")
print(pp)
# SaveFigure("fig2")
