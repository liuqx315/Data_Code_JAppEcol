rm(list = ls())
library("agricolae")
require("ggplot2")
require("gplots")   # Package with special plot functions
require("car")      # Anova, levene.test, outlier.test
require("stats")
require("sciplot")
library("car")
require("dplyr")
library("rlist")
library("ggsci")
library("scales")
library("cowplot")
library("betareg")
library("multcomp")
stderr <- function(x) sqrt(var(x,na.rm=T)/length(which(!is.na(x))))
OpenWindow = function (Width,Height) {
  if (Sys.info()["sysname"]=="Darwin"){  # (Darwin stands for a Mac computer)
    quartz(width=Width, height=Height)           
  } else {
    windows(width = Width, height = Height)}
}

SaveFigure=function(FileName){
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz.save(paste(FileName,'.pdf',sep=''),type = c("pdf"),device = dev.cur())
  } else
    savePlot(filename = FileName,type = c("pdf"),device = dev.cur(),restoreConsole = TRUE) 
}
Colors = pal_jco("default",alpha = 0.75)(10)
Colors = Colors[c(1,2,8)]
dat = read.csv("scirpus_spartina.csv")
dat$species = factor(dat$species)
dat$elevation = factor(dat$elevation)
dat$site = factor(dat$site)
dat$type = factor(dat$type)
coln = which(colnames(dat) == "density")
dat1 = by(dat,dat$site,function(x)(x[,coln] =(x[,coln]/x[,coln][1] )))##Standardize Data
Elevation = c(rep("Low elevation",length(levels(dat$site))/2),
              rep("High elevation",length(levels(dat$site))/2))
Pattern = dat$type[dat$Days == 1]
Species = dat$species[dat$Days == 1]
Site = dat$site[dat$Days == 1]
Survivorship = unlist(dat1)
dat3 = data.frame(dat,Survivorship)
row.names(dat3) <-NULL
colsur = which(colnames(dat3) == "Survivorship")
colday = which(colnames(dat3) == "Days")
dat_Sur = dat3[dat3$Days == 29|dat3$Days == 30,]
Survivorship2 = dat_Sur$Survivorship
Species_Pattern = dat_Sur$species_pattern
##################Survivorship###########################################
Survivor2 = data.frame(Site,Elevation,Pattern,Species,Survivorship2,Species_Pattern)
Survivor2$Species_Pattern = as.factor(Survivor2$Species_Pattern)
Survivor2$Survivorship2 = Survivor2$Survivorship2*100
Survivorlow = Survivor2[Survivor2$Elevation == "Low elevation",]
Survivorhigh = Survivor2[Survivor2$Elevation == "High elevation",]
m1 = aov(Survivorship2~Species*Pattern,Survivorhigh)
shapiro.test(resid(m1))
leveneTest(m1)
Anova(m1,type = "II")
m1_mulcp = aov(Survivorship2~Species_Pattern,Survivorhigh)
TukeyHSD(m1_mulcp);high_S <- HSD.test(m1_mulcp, 'Species_Pattern');print(high_S$groups)
mulcp1 = glht(m1_mulcp, linfct = mcp(Species_Pattern= "Tukey"));summary(mulcp1)

m2 = aov(Survivorship2~Species*Pattern,Survivorlow)
shapiro.test(resid(m2))
leveneTest(m2)
Anova(m2,type = "II")
m2_mulcp = aov(Survivorship2~Species_Pattern,Survivorlow)
low_S <- HSD.test(m2_mulcp, 'Species_Pattern');print(low_S$groups)
mulcp2 = glht(m2_mulcp, linfct = mcp(Species_Pattern= "Tukey"));summary(mulcp2)
######################plant density change##############################
dat4 = by(dat3,dat$site,function(x)glm(x[,colsur]~x[,colday]))
dat5 = t(as.data.frame(lapply(dat4,coef)))
decrease_rate = dat5[,2]
Decrease = data.frame(levels(dat$site),Elevation,Pattern,Species,decrease_rate)
Species_Pattern2 = paste0(Decrease$Species,seq="-",Decrease$Pattern)
Decrease = data.frame(Decrease,Species_Pattern2)
Decrease$Species_Pattern2 = as.factor(Decrease$Species_Pattern2)
Decrease$decrease_rate = Decrease$decrease_rate*100
Decreaselow = Decrease[Survivor2$Elevation == "Low elevation",]
Decreasehigh = Decrease[Survivor2$Elevation == "High elevation",]
m3 = aov(decrease_rate~Species*Pattern,Decreasehigh)
shapiro.test(resid(m3))
leveneTest(m3)
Anova(m3,type = "II")
m3_mulcp = aov(decrease_rate~Species_Pattern2,Decreasehigh)
high_P<- HSD.test(m3_mulcp, 'Species_Pattern2');print(high_P$groups)
mulcp3 = glht(m3_mulcp, linfct = mcp(Species_Pattern2= "Tukey"));summary(mulcp3)

m4 = aov(decrease_rate~Species*Pattern,Decreaselow)
shapiro.test(resid(m4))
leveneTest(m4)
Anova(m4,type = "II")
m4_mulcp = aov(decrease_rate~Species_Pattern2,Decreaselow)
Low_P<- HSD.test(m4_mulcp, 'Species_Pattern2');print(Low_P$groups)
mulcp4 = glht(m4_mulcp, linfct = mcp(Species_Pattern2= "Tukey"));summary(mulcp4)

##########fig2#########################################################################
Pattern_groups=c("Clumped","Dispersed")
Species_groups=c("Scirpus","Spartina")
Elevation_groups = c("High elevation","Low elevation")
OpenWindow(12,8)
par(mfrow = c(1,2))
bargraph.CI(Pattern,Survivorship2, group = Species, data = Survivorhigh,
            col = Colors[1:2],
            names.arg = Pattern_groups,
            ci.fun = function(x) c(mean(x)-sqrt(var(x,na.rm=T)/length(which(!is.na(x)))),
                                   mean(x)+sqrt(var(x,na.rm=T)/length(which(!is.na(x))))),
            xlab = "", ylab = (" Survivorship (%)"),cex.lab=1.5,
            cex.name = 1.5,cex.axis=1.5,
            ylim = c(0,100),cex=1.5,cex.lab=1.5,las=1.0,
            lwd = 2.5)
mtext("AP : P = 0.463",side=1, adj=0.05,padj=-30,cex=1.5,font = 3)
mtext("SP : P < 0.001***",side=1, adj=0.05,padj=-28.5,cex=1.5,font = 3)
mtext("AP x SP : P = 0.107",side=1, adj=0.05,padj=-27,cex=1.5,font = 3)
# legend("topright", legend = Species_groups,
#        bty = "n", horiz = F, fill = Colors, cex=1.5)

bargraph.CI(Pattern,decrease_rate, group = Species, data = Decreasehigh,
            col = Colors[1:2],
            names.arg = Pattern_groups,
            ci.fun = function(x) c(mean(x)-sqrt(var(x,na.rm=T)/length(which(!is.na(x)))),
                                   mean(x)+sqrt(var(x,na.rm=T)/length(which(!is.na(x))))),
            xlab = "", ylab = (" Plant density  change (%)"),cex.lab=1.5,
            cex.name = 1.5,cex.axis=1.5,
            ylim = c(-4,3),cex=1.5,cex.lab=1.5,las=1.0,
            lwd = 2.5)
mtext("AP : P = 0.180",side=1, adj=0.05,padj=-30,cex=1.5,font = 3)
mtext("SP : P < 0.001***",side=1, adj=0.05,padj=-28.5,cex=1.5,font = 3)
mtext("AP x SP : P = 0.005**",side=1, adj=0.05,padj=-27,cex=1.5,font = 3)
legend("topright", legend = Species_groups,
       bty = "n", horiz = F, fill = Colors, cex=1.5)
SaveFigure("Fig5_1")

OpenWindow(12,8)
par(mfrow = c(1,2))
bargraph.CI(Pattern,Survivorship2, group = Species, data = Survivorlow,
            col = Colors[1:2],
            names.arg = Pattern_groups,
            ci.fun = function(x) c(mean(x)-sqrt(var(x,na.rm=T)/length(which(!is.na(x)))),
                                   mean(x)+sqrt(var(x,na.rm=T)/length(which(!is.na(x))))),
            xlab = "", ylab = (" Survivorship (%)"),cex.lab=1.5,
            cex.name = 1.5,cex.axis=1.5,
            ylim = c(0,100),cex=1.5,cex.lab=1.5,las=1.0,
            lwd = 2.5)
mtext("AP : P = 0.004**",side=1, adj=0.05,padj=-30,cex=1.5,font = 3)
mtext("SP : P = 0.001**",side=1, adj=0.05,padj=-28.5,cex=1.5,font = 3)
mtext("AP x SP : P = 0.102",side=1, adj=0.05,padj=-27,cex=1.5,font = 3)
# legend("topright", legend = Species_groups,
#        bty = "n", horiz = F, fill = Colors, cex=1.5)

bargraph.CI(Pattern,decrease_rate, group = Species, data = Decreaselow,
            col = Colors[1:2],
            names.arg = Pattern_groups,
            ci.fun = function(x) c(mean(x)-sqrt(var(x,na.rm=T)/length(which(!is.na(x)))),
                                   mean(x)+sqrt(var(x,na.rm=T)/length(which(!is.na(x))))),
            xlab = "", ylab = (" Plant density  change (%)"),cex.lab=1.5,
            cex.name = 1.5,cex.axis=1.5,
            ylim = c(-4,3),cex=1.5,cex.lab=1.5,las=1.0,
            lwd = 2.5)
legend("topright", legend = Species_groups,
       bty = "n", horiz = F, fill = Colors, cex=1.5)
mtext("AP : P = 0.107",side=1, adj=0.05,padj=-30,cex=1.5,font = 3)
mtext("SP : P = 0.003**",side=1, adj=0.05,padj=-28.5,cex=1.5,font = 3)
mtext("AP x SP : P = 0.03*",side=1, adj=0.05,padj=-27,cex=1.5,font = 3)
SaveFigure("Fig5_2")

# Survivor2$Elevation = factor(Survivor2$Elevation)
# Survivor2$Pattern = factor(Survivor2$Pattern)
# Survivor2$Species = factor(Survivor2$Species)
# mean_Sur2 = Survivor2%>%group_by(Elevation,Pattern,Species)%>%summarise(Survivor_se = stderr(Survivorship2),Survivorship = mean(Survivorship2))
# mean_Dcre2 = Decrease%>%group_by(Elevation,Pattern,Species)%>%summarise(decrease_se = stderr(decrease_rate),decrease_rate = mean(decrease_rate))

