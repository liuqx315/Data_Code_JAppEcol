rm(list = ls())
library("dplyr")
library("ggplot2")
require("gplots")   # Package with special plot functions
require("car")      # Anova, levene.test, outlier.test
require("stats")
require("sciplot")
library("agricolae")
library("ggsci")
library("scales")
library("emmeans")
stderr <- function(x) sqrt(var(x,na.rm=T)/length(which(!is.na(x))))
dat = read.csv("area change.csv",header = T)
dat$Elevation[dat$Elevation == 1] <- "High elevation"
dat$Elevation[dat$Elevation == 2] <- "Low elevation"

dat1 = dat[dat$Week == 11,]
# dat2 = dat[dat$Week == 0,]
OpenWindow = function (WinWidth,WinHeight) {
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz(width=WinWidth, height=WinHeight, 
           title=" ")
  } else
    windows(width = WinWidth, height = WinHeight,
            title=" ")
}
SaveFigure=function(FileName){
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz.save(paste(FileName,'.pdf',sep=''),type = c("pdf"),device = dev.cur())
  } else
    savePlot(filename = FileName,type = c("pdf"),device = dev.cur(),restoreConsole = TRUE) 
}

# Colors = brewer.pal(3, "") #Accent,Dark2,Paired,Pastel1,Pastel1,Set1,Set2,Set3
Colors = pal_jco("default",alpha = 0.75)(10)
Colors = Colors[c(1,2,8)]
Pattern_groups=c("Clumped","Random","Regular")
Connectivity_groups=c("High connectance","Low connectance","No connectance")
Elevation_groups=c("High elevation","Low elevation")
Configuration_groups=c("Cluster","Dispersal")
OpenWindow(8,7)
par(mar=c(3.2, 5, 2.2, 0.1) + 0.1)
bargraph.CI(Connectivity,Area, group = Pattern, data = dat1,
            col = Colors,
            names.arg=Connectivity_groups,
            ci.fun = function(x) c(mean(x)-sqrt(var(x,na.rm=T)/length(which(!is.na(x)))),
                                   mean(x)+sqrt(var(x,na.rm=T)/length(which(!is.na(x))))),
            xlab = "", ylab = ("Plant mean cover area at last week "~(m^2)),cex.lab=1.5,
            cex.name = 1.5,cex.axis=1.5,
            ylim = c(0,7.5),cex=1.5,cex.lab=1.5,las=1.0,
            lwd = 2.5)
lines(c(1.3,3.7,1.3,3.7), y = c(3.25,3.25,3.25,3.25), lty = 1.25,lwd=2)
lines(c(5.25,7.75,5.25,7.75), y = c(4.9,4.9,4.9,4.9), lty = 1.25,lwd=2)
lines(c(9.25,11.75,9.25,11.75), y = c(4.55,4.55,4.55,4.55), lty = 1.25,lwd=2)

mtext("AP : P = 0.166",side=1, adj=0.05,padj=-30,cex=1.5,font = 3)
mtext("BC : P < 0.001***",side=1, adj=0.05,padj=-28.5,cex=1.5,font = 3)
mtext("AP x BC : P = 0.885",side=1, adj=0.05,padj=-27,cex=1.5,font = 3)

legend("topright", legend = Pattern_groups,
       bty = "n", horiz = F, fill = Colors, cex=1.5)
SaveFigure("fig4")
#############Statistic########################################################

dat1 = dat[dat$Week == 11,]
m1 = aov(Area~Pattern*Connectivity,data = dat1)
print(leveneTest(m1))
print(anova(m1))
dat2 = dat1%>%group_by(Connectivity,Pattern)%>%summarise(Area_se = stderr(Area),Area = mean(Area))
dat_connectance = dat1%>%group_by(Connectivity)%>%summarise(Area_se = stderr(Area),Area = mean(Area))
# lsmeans(m1,pairwise ~ Connectivity,p.adjust.methods = 'bonf')
emmeans(m1,pairwise ~ Connectivity)
result = HSD.test(m1,"Connectivity")
m1.1 = aov(Area~Connectance_Pattern,data = dat1)
result = HSD.test(m1.1,"Connectance_Pattern",group = T)
print(result)
# Anova(m1,type = "II")
