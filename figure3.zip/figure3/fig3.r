rm(list = ls())
require("ggplot2")
require("gplots")   # Package with special plot functions
require("car")      # Anova, levene.test, outlier.test
require("stats")
require("sciplot")
library("RColorBrewer")
library("car")
require("dplyr")
library("emmeans")
library("ggsci")
library("scales")
library("agricolae")
stderr <- function(x) sqrt(var(x,na.rm=T)/length(which(!is.na(x))))
OpenWindow = function (Width,Height) {
  if (Sys.info()["sysname"]=="Darwin"){  # (Darwin stands for a Mac computer)
    quartz(width=Width, height=Height)           
  } else {
    windows(width = Width, height = Height)}
}

SaveFigure=function(FileName){
  if (Sys.info()["sysname"]=="Darwin"){ # (Darwin stands for a Mac computer)
    quartz.save(paste(FileName,'.pdf',sep=''),type = c("pdf"),device = dev.cur())
  } else
    savePlot(filename = FileName,type = c("pdf"),device = dev.cur(),restoreConsole = TRUE) 
}
dat = read.csv("Pattern_Connectance2019.csv")
dat = dat[dat$Week<12,] ##typhoon happened in 12 week###
site = c(paste0(dat$Transect,seq="_",dat$Replicate,seq="_",dat$Plot))
dat = cbind(site,dat)         
dat$site = as.factor(dat$site)
dat1.1 = dat[dat$Week<=4,]##first 4 weeks###
dat1.2 = dat[dat$Week>4,]##remaining weeks##
Site = levels(dat$site)
Elevation = c(rep("High elevation",length(levels(dat$site))/2),rep("Low elevation",length(levels(dat$site))/2))
Pattern = rep(c("Regular","Random","Clumped"),length(levels(dat$site))/3)
Connectance = rep(rep(c("High connectance","Low connectance","No connectance"),each = 3),length(levels(dat$site))/9)
Configuration = rep(c("Dispersal","Dispersal","Cluster"),length(levels(dat$site))/3)
Connectance_Pattern = rep(c("HRE","HRA","HC","LRE","LRA","LC","NRE","NRA","NC"),length(levels(dat$site))/9)
####################First 4 weeks##########################################
coln1 = which(colnames(dat1.1) == "Plant_Density")
coln2 = which(colnames(dat1.1) == "Week")
dat2.1 = by(dat1.1,dat1.1$site,function(x)glm(x[,coln1]~x[,coln2]))
dat3.1 = as.data.frame(lapply(dat2.1,coef))
dat3.1 = t(dat3.1)
Slope = dat3.1[,2]
dat_slope_first4 = data.frame(Site,Elevation,Pattern,Configuration,Connectance,Connectance_Pattern,Slope)
write.csv(dat_slope_first4,"dat_slope_f4.csv",row.names = F)
# rownames(dat_slope_first4)<-NULL
dat_slope_F4 = dat_slope_first4%>%group_by(Elevation,Pattern,Configuration,Connectance)%>%
  summarise(Slope_SE = stderr(Slope),Slope_mean = mean(Slope,na.rm =T))
##################Remaining weeks##########################################
dat2.2 = by(dat1.2,dat1.2$site,function(x)glm(x[,coln1]~x[,coln2]))
dat3.2 = as.data.frame(lapply(dat2.2,coef))
dat3.2 = t(dat3.2)
Site = levels(dat$site)
Slope = dat3.2[,2]
dat_slope_remain = data.frame(Site,Elevation,Pattern,Configuration,Connectance,Connectance_Pattern,Slope)
write.csv(dat_slope_remain,"dat_slope_remain.csv",row.names = F)
dat_slope_RM = dat_slope_remain%>%group_by(Elevation,Pattern,Configuration,Connectance)%>%
  summarise(Slope_SE = stderr(Slope),Slope_mean = mean(Slope,na.rm =T))
# rownames(dat_slope_remain)<-NULL

Colors = pal_jco("default",alpha = 0.75)(10)
Colors = Colors[c(1,2,8)]
##################Plot figure 3A###############################################
OpenWindow(11.5,10)
dat_slope_F4$Elevation = factor(dat_slope_F4$Elevation)
dat_slope_F4$Pattern = factor(dat_slope_F4$Pattern)
dat_slope_F4$Connectance= factor(dat_slope_F4$Connectance)

ggplot(dat_slope_F4, aes(y=Slope_mean,x=Pattern, color = Connectance,ymin=-5, ymax=40,)) + 
  facet_grid(Elevation~.)+ coord_flip()+
  # facet_grid(Elevation~Pattern,space='fixed')+
  geom_point(size = 4,position = position_dodge(0.75))+
  geom_errorbar(aes(ymin=Slope_mean-Slope_SE, ymax=Slope_mean+Slope_SE),width = 0.3,size = 1.2, position = position_dodge(0.75))+
  # geom_pointrange(position = position_dodge(0.75),fatten = 7.5)+
  scale_color_manual(values=Colors)+theme_bw()+
  theme(plot.title = element_text(size=16,hjust=0.5),
        # text = element_text(family="Times New Roman",color = "black"),
        legend.text = element_text(size=16,hjust=0.5),
        legend.title = element_text(size=16,face = 'bold'),
        legend.key=element_rect(fill='NA'),
        strip.text.x = element_text(size=20,face="bold"),
        strip.text.y = element_text(size=20,face="bold"),
        axis.title.x = element_text(size = 18,vjust = 0.0,color='black',face="bold"),
        axis.title.y = element_text(size = 18,hjust = 0.5,color='black',face="bold"),
        axis.text.x  = element_text(size = 16,vjust = 0.5,hjust=0.5,color='black'), 
        axis.text.y  = element_text(size = 16,color='black',hjust = 0.5),
        axis.ticks   = element_line(colour = "black", size = 0.75),
        axis.ticks.length=unit(.20, "cm"),
        # legend.position=c(0.0,0.85),
        legend.position="top") +
  # geom_vline(xintercept = 4)+
  xlab("Spatial configuration") +
  ylab("Recolonization rate at first 4 weeks") 
# # geom_hline(yintercept = 200,linetype=2,lwd=1)+
# # annotate("text",x=1.5,y=275,label="n=6",size = 6)+
# SaveFigure("fig3A")
##################Plot figure 3B###############################################
OpenWindow(11.5,10)
dat_slope_RM$Elevation = factor(dat_slope_RM$Elevation)
dat_slope_RM$Pattern = factor(dat_slope_RM$Pattern)
dat_slope_RM$Connectance= factor(dat_slope_RM$Connectance)
ggplot(dat_slope_RM, aes(y=Slope_mean,x=Pattern, color = Connectance,ymin=-5, ymax=40)) + 
  facet_grid(Elevation~.)+ coord_flip()+
  # facet_grid(Elevation~Pattern,space='fixed')+
  geom_point(size = 4,position = position_dodge(0.75))+
  geom_errorbar(aes(ymin=Slope_mean-Slope_SE, ymax=Slope_mean+Slope_SE),width = 0.3,size = 1.2, position = position_dodge(0.75))+
  # geom_pointrange(position = position_dodge(0.75),fatten = 7.5)+
  scale_color_manual(values=Colors)+theme_bw()+
  theme(plot.title = element_text(size=16,hjust=0.5),
        # text = element_text(family="Times New Roman",color = "black"),
        legend.text = element_text(size=16,hjust=0.5),
        legend.title = element_text(size=16,face = 'bold'),
        legend.key=element_rect(fill='NA'),
        strip.text.x = element_text(size=20,face="bold"),
        strip.text.y = element_text(size=20,face="bold"),
        axis.title.x = element_text(size = 18,vjust = 0.0,color='black',face="bold"),
        axis.title.y = element_text(size = 18,hjust = 0.5,color='black',face="bold"),
        axis.text.x  = element_text(size = 16,vjust = 0.5,hjust=0.5,color='black'), 
        axis.text.y  = element_text(size = 16,color='black',hjust = 0.5),
        axis.ticks   = element_line(colour = "black", size = 0.75),
        axis.ticks.length=unit(.20, "cm"),
        # legend.position=c(0.0,0.85),
        legend.position="top") +
  # geom_hline(yintercept = 25, linetype=2, lwd=1)+
  xlab("Spatial configuration") +
  ylab("Recolonization rate at remaining weeks") 
# # geom_hline(yintercept = 200,linetype=2,lwd=1)+
# # annotate("text",x=1.5,y=275,label="n=6",size = 6)+
# SaveFigure("fig3B")
